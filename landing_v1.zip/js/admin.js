(function () {



    let btnAnimar = document.querySelector("#btn-animar");

    document.addEventListener("keydown", function (eventKd) {
        /*console.log("presionar");
        console.log(eventKd);*/
        if (eventKd.keyCode == 32 && !event.target.matches('input[type="text"]')) {
            if (localStorage.getItem("totopos-ole-btn-animar")) {
                localBtnAnimar = localStorage.getItem("totopos-ole-btn-animar");
                localStorage.setItem("totopos-ole-btn-animar", true);
            } else {
                localStorage.setItem("totopos-ole-btn-animar", true);
            }
        }
    });

    document.addEventListener("keyup", function (eventKu) {
        /*console.log("soltar");
        console.log(eventKu);*/
        if (eventKu.keyCode == 32 && !event.target.matches('input[type="text"]')) {
            if (localStorage.getItem("totopos-ole-btn-animar")) {
                localBtnAnimar = localStorage.getItem("totopos-ole-btn-animar");
                localStorage.setItem("totopos-ole-btn-animar", false);
            } else {
                localStorage.setItem("totopos-ole-btn-animar", true);
            }
        }
    });


    btnAnimar.addEventListener('mousedown', function () {
        if (localStorage.getItem("totopos-ole-btn-animar")) {
            localBtnAnimar = localStorage.getItem("totopos-ole-btn-animar");
            localStorage.setItem("totopos-ole-btn-animar", true);
        } else {
            localStorage.setItem("totopos-ole-btn-animar", true);
        }
    });

    btnAnimar.addEventListener('mouseup', function () {
        if (localStorage.getItem("totopos-ole-btn-animar")) {
            localBtnAnimar = localStorage.getItem("totopos-ole-btn-animar");
            localStorage.setItem("totopos-ole-btn-animar", false);
        } else {
            localStorage.setItem("totopos-ole-btn-animar", true);
        }
    });

    let btnMensaje = document.querySelector(".send-message input[type='submit']");

    let soundEfects = document.querySelectorAll(".cont-btn button");

    soundEfects.forEach(function (soundEfect) {
        soundEfect.addEventListener("click", function () {
            var audio = document.querySelector(`audio#${this.id}`);
            console.log(audio);
            // Agregar un controlador de eventos clic al botón
            // button.addEventListener("click", function () {
            // Comprobar si el audio está reproduciéndose actualmente
            if (audio.paused) {
                // Si el audio está en pausa, reproducirlo
                audio.play();
            } else {
                // Si el audio se está reproduciendo, detenerlo y volver al inicio
                audio.pause();
                audio.currentTime = 0;
                audio.play();
            }
            // });
        });
    });

    let frasesGenericas = document.querySelectorAll(".cont-btn-frases button");

    frasesGenericas.forEach(function (fraseGenerica) {
        fraseGenerica.addEventListener("click", function () {
            capturarMensaje(this.innerText);
        });
    });

    btnMensaje.addEventListener("click", () => {
        capturarMensaje(document.querySelector("#mensaje").value);
    });

    document.querySelector("#mensaje").addEventListener("keyup", function (event) {
        if (event.key === "Enter") {
            capturarMensaje(this.value);
        }
    });

    let btnStages = document.querySelectorAll(".cont-btn-escenarios button");

    btnStages.forEach(function (btnStage) {
        btnStage.addEventListener("click", function () {
            // localStorage.removeItem("totopos-ole-escenario");
            localStorage.setItem("totopos-ole-escenario", this.id);
        });
    });

    function capturarMensaje(mensaje) {
        const texto = mensaje;
        /*const palabras = texto.split(" ");
        const lineas = [];

        let localStorageText = "";

        for (let i = 0; i < palabras.length; i += 3) {
            lineas.push(palabras.slice(i, i + 3).join(" "));
        }

        lineas.forEach((linea, index) => {
            const lineaDiv = document.createElement("div");
            lineaDiv.innerText = linea;
            lineaDiv.classList.add("typewriter");
            lineaDiv.style.animationDelay = `${index * 1}s`;
            lineaDiv.style.animationTimingFunction = `steps(${linea.length}, end)`;
            localStorageText += lineaDiv.outerHTML;
        });*/

        localStorageText = texto.replace(/(\S+\s*){3}/g, "$&<br>");

        localStorage.setItem("totopos-ole-enviar-texto", localStorageText);
        document.querySelector("#mensaje").value = "";
    }

    let btnSnaps = document.querySelectorAll(".cont-btn-cierres button");

    btnSnaps.forEach(function (btnSnap) {
        btnSnap.addEventListener("click", function () {
            localStorage.removeItem("totopos-ole-cierre");
            localStorage.setItem("totopos-ole-cierre", this.id);
        });
    });

    // Purgar el local storage
    localStorage.removeItem("totopos-ole-escenario");
    localStorage.removeItem("totopos-ole-cierre");

})();